﻿
namespace CovidVaccination
{
    partial class GetHelp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GetHelp));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Resources = new System.Windows.Forms.Label();
            this.Basics = new System.Windows.Forms.LinkLabel();
            this.Spread = new System.Windows.Forms.LinkLabel();
            this.Prevention = new System.Windows.Forms.LinkLabel();
            this.ifyouor = new System.Windows.Forms.LinkLabel();
            this.Children = new System.Windows.Forms.LinkLabel();
            this.Vaccine = new System.Windows.Forms.LinkLabel();
            this.Outbreak = new System.Windows.Forms.LinkLabel();
            this.Symptoms = new System.Windows.Forms.LinkLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CovidVaccination.Properties.Resources.background;
            this.pictureBox1.Location = new System.Drawing.Point(1, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(655, 422);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(557, 383);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 24);
            this.button1.TabIndex = 2;
            this.button1.Text = "Main Menu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(230, 407);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Copyright © 2021 Created by the Agile Warriors";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 151);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "FAQ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 217);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "Helpful Links:";
            // 
            // Resources
            // 
            this.Resources.AutoSize = true;
            this.Resources.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Resources.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resources.Location = new System.Drawing.Point(22, 319);
            this.Resources.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Resources.Name = "Resources";
            this.Resources.Size = new System.Drawing.Size(71, 19);
            this.Resources.TabIndex = 10;
            this.Resources.Text = "Resources";
            // 
            // Basics
            // 
            this.Basics.ActiveLinkColor = System.Drawing.Color.White;
            this.Basics.AutoSize = true;
            this.Basics.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Basics.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Basics.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Basics.LinkColor = System.Drawing.Color.MediumPurple;
            this.Basics.Location = new System.Drawing.Point(24, 242);
            this.Basics.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Basics.Name = "Basics";
            this.Basics.Size = new System.Drawing.Size(40, 16);
            this.Basics.TabIndex = 11;
            this.Basics.TabStop = true;
            this.Basics.Text = "Basics";
            this.Basics.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Basics_LinkClicked);
            // 
            // Spread
            // 
            this.Spread.ActiveLinkColor = System.Drawing.Color.White;
            this.Spread.AutoSize = true;
            this.Spread.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Spread.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Spread.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Spread.LinkColor = System.Drawing.Color.MediumPurple;
            this.Spread.Location = new System.Drawing.Point(23, 280);
            this.Spread.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Spread.Name = "Spread";
            this.Spread.Size = new System.Drawing.Size(44, 16);
            this.Spread.TabIndex = 12;
            this.Spread.TabStop = true;
            this.Spread.Text = "Spread";
            this.Spread.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Spread_LinkClicked);
            // 
            // Prevention
            // 
            this.Prevention.ActiveLinkColor = System.Drawing.Color.White;
            this.Prevention.AutoSize = true;
            this.Prevention.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Prevention.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Prevention.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prevention.LinkColor = System.Drawing.Color.MediumPurple;
            this.Prevention.Location = new System.Drawing.Point(23, 261);
            this.Prevention.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Prevention.Name = "Prevention";
            this.Prevention.Size = new System.Drawing.Size(65, 16);
            this.Prevention.TabIndex = 13;
            this.Prevention.TabStop = true;
            this.Prevention.Text = "Prevention";
            this.Prevention.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Prevention_LinkClicked);
            // 
            // ifyouor
            // 
            this.ifyouor.ActiveLinkColor = System.Drawing.Color.White;
            this.ifyouor.AutoSize = true;
            this.ifyouor.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ifyouor.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ifyouor.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ifyouor.LinkColor = System.Drawing.Color.MediumPurple;
            this.ifyouor.Location = new System.Drawing.Point(23, 175);
            this.ifyouor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ifyouor.Name = "ifyouor";
            this.ifyouor.Size = new System.Drawing.Size(216, 16);
            this.ifyouor.TabIndex = 14;
            this.ifyouor.TabStop = true;
            this.ifyouor.Text = "What to do when you\'ve been exposed.";
            this.ifyouor.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ifyouor_LinkClicked);
            // 
            // Children
            // 
            this.Children.ActiveLinkColor = System.Drawing.Color.White;
            this.Children.AutoSize = true;
            this.Children.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Children.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Children.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Children.LinkColor = System.Drawing.Color.MediumPurple;
            this.Children.Location = new System.Drawing.Point(23, 299);
            this.Children.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Children.Name = "Children";
            this.Children.Size = new System.Drawing.Size(52, 16);
            this.Children.TabIndex = 15;
            this.Children.TabStop = true;
            this.Children.Text = "Children";
            this.Children.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Children_LinkClicked);
            // 
            // Vaccine
            // 
            this.Vaccine.ActiveLinkColor = System.Drawing.Color.White;
            this.Vaccine.AutoSize = true;
            this.Vaccine.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Vaccine.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Vaccine.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vaccine.LinkColor = System.Drawing.Color.MediumPurple;
            this.Vaccine.Location = new System.Drawing.Point(23, 345);
            this.Vaccine.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Vaccine.Name = "Vaccine";
            this.Vaccine.Size = new System.Drawing.Size(49, 16);
            this.Vaccine.TabIndex = 16;
            this.Vaccine.TabStop = true;
            this.Vaccine.Text = "Vaccine";
            this.Vaccine.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Vaccine_LinkClicked);
            // 
            // Outbreak
            // 
            this.Outbreak.ActiveLinkColor = System.Drawing.Color.White;
            this.Outbreak.AutoSize = true;
            this.Outbreak.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Outbreak.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Outbreak.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Outbreak.LinkColor = System.Drawing.Color.MediumPurple;
            this.Outbreak.Location = new System.Drawing.Point(23, 365);
            this.Outbreak.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Outbreak.Name = "Outbreak";
            this.Outbreak.Size = new System.Drawing.Size(136, 16);
            this.Outbreak.TabIndex = 17;
            this.Outbreak.TabStop = true;
            this.Outbreak.Text = "Preparing for a outbreak";
            this.Outbreak.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Outbreak_LinkClicked);
            // 
            // Symptoms
            // 
            this.Symptoms.ActiveLinkColor = System.Drawing.Color.White;
            this.Symptoms.AutoSize = true;
            this.Symptoms.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Symptoms.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Symptoms.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Symptoms.LinkColor = System.Drawing.Color.MediumPurple;
            this.Symptoms.Location = new System.Drawing.Point(23, 385);
            this.Symptoms.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Symptoms.Name = "Symptoms";
            this.Symptoms.Size = new System.Drawing.Size(196, 16);
            this.Symptoms.TabIndex = 18;
            this.Symptoms.TabStop = true;
            this.Symptoms.Text = "Symptoms and Emergency warning ";
            this.Symptoms.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Symptoms_LinkClicked);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox1.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(27, 21);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(591, 126);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.White;
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.linkLabel1.DisabledLinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.MediumPurple;
            this.linkLabel1.Location = new System.Drawing.Point(23, 195);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(191, 16);
            this.linkLabel1.TabIndex = 21;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "What to do if you start feeling sick.";
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(263, 166);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(367, 212);
            this.webBrowser1.TabIndex = 22;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // GetHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 422);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Symptoms);
            this.Controls.Add(this.Outbreak);
            this.Controls.Add(this.Vaccine);
            this.Controls.Add(this.Children);
            this.Controls.Add(this.ifyouor);
            this.Controls.Add(this.Prevention);
            this.Controls.Add(this.Spread);
            this.Controls.Add(this.Basics);
            this.Controls.Add(this.Resources);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "GetHelp";
            this.Text = "GetHelp";
            this.Load += new System.EventHandler(this.GetHelp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Resources;
        private System.Windows.Forms.LinkLabel Basics;
        private System.Windows.Forms.LinkLabel Spread;
        private System.Windows.Forms.LinkLabel Prevention;
        private System.Windows.Forms.LinkLabel ifyouor;
        private System.Windows.Forms.LinkLabel Children;
        private System.Windows.Forms.LinkLabel Vaccine;
        private System.Windows.Forms.LinkLabel Outbreak;
        private System.Windows.Forms.LinkLabel Symptoms;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}