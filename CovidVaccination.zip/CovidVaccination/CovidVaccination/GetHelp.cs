﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CovidVaccination
{
    public partial class GetHelp : Form
    {
        public GetHelp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainMenu mform = new MainMenu();
            mform.Show();
            this.Hide();
        }

        private void GetHelp_Load(object sender, EventArgs e)
        {
            
        }

        private void Basics_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Basics");
        }

        private void Prevention_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Prevention");
        }

        private void ifyouor_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#If-You-or-Someone-You-Know-is-Sick-or-Had-Contact-with-Someone-who-Has-COVID-19");
        }

        private void Spread_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Spread");
        }

        private void Vaccine_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Vaccines");
        }

        private void Children_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Children");
        }

        private void Outbreak_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Preparing-for-an-Outbreak");
        }

        private void Symptoms_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.cdc.gov/coronavirus/2019-ncov/faq.html#Symptoms-&-Emergency-Warning-Signs");
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
           
            webBrowser1.Navigate("https://www.youtube.com/watch?v=Jr2DbSqcM7I/apiplayer?video_id=HLj0aLPLsys&version=3");
        }
    }
}
