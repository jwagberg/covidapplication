﻿
namespace CovidVaccination
{
    partial class GetVaccine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.main_menu_btn = new System.Windows.Forms.Button();
            this.genderDrop = new System.Windows.Forms.ComboBox();
            this.Gender = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.Label();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.lname_txt = new System.Windows.Forms.TextBox();
            this.fname_txt = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.Label();
            this.register_btn = new System.Windows.Forms.Button();
            this.Address = new System.Windows.Forms.Label();
            this.State = new System.Windows.Forms.Label();
            this.address_txt = new System.Windows.Forms.TextBox();
            this.Statetxt = new System.Windows.Forms.TextBox();
            this.zip_txt = new System.Windows.Forms.TextBox();
            this.ZipCode = new System.Windows.Forms.Label();
            this.Pregnanttxt = new System.Windows.Forms.Label();
            this.pregDrop = new System.Windows.Forms.ComboBox();
            this.Preexisting = new System.Windows.Forms.Label();
            this.existing_txt = new System.Windows.Forms.TextBox();
            this.date_birth = new System.Windows.Forms.DateTimePicker();
            this.phone_lbl = new System.Windows.Forms.Label();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(1, 1);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(1, 20);
            this.dateTimePicker1.TabIndex = 45;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 404);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 13);
            this.label1.TabIndex = 44;
            this.label1.Text = "Copyright © 2021 Created by the Agile Warriors";
            // 
            // main_menu_btn
            // 
            this.main_menu_btn.Location = new System.Drawing.Point(558, 337);
            this.main_menu_btn.Margin = new System.Windows.Forms.Padding(2);
            this.main_menu_btn.Name = "main_menu_btn";
            this.main_menu_btn.Size = new System.Drawing.Size(83, 24);
            this.main_menu_btn.TabIndex = 13;
            this.main_menu_btn.Text = "Main Menu";
            this.main_menu_btn.UseVisualStyleBackColor = true;
            this.main_menu_btn.Click += new System.EventHandler(this.main_menu_btn_Click);
            // 
            // genderDrop
            // 
            this.genderDrop.FormattingEnabled = true;
            this.genderDrop.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other ",
            "Prefer Not to Say"});
            this.genderDrop.Location = new System.Drawing.Point(102, 118);
            this.genderDrop.Margin = new System.Windows.Forms.Padding(2);
            this.genderDrop.Name = "genderDrop";
            this.genderDrop.Size = new System.Drawing.Size(162, 21);
            this.genderDrop.TabIndex = 6;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Location = new System.Drawing.Point(15, 118);
            this.Gender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(45, 13);
            this.Gender.TabIndex = 39;
            this.Gender.Text = "Gender:";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(15, 76);
            this.Email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(35, 13);
            this.Email.TabIndex = 40;
            this.Email.Text = "Email:";
            // 
            // DOB
            // 
            this.DOB.AutoSize = true;
            this.DOB.Location = new System.Drawing.Point(15, 58);
            this.DOB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(69, 13);
            this.DOB.TabIndex = 41;
            this.DOB.Text = "Date of Birth:";
            // 
            // email_txt
            // 
            this.email_txt.Location = new System.Drawing.Point(102, 76);
            this.email_txt.Margin = new System.Windows.Forms.Padding(2);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(162, 20);
            this.email_txt.TabIndex = 4;
            // 
            // lname_txt
            // 
            this.lname_txt.Location = new System.Drawing.Point(102, 34);
            this.lname_txt.Margin = new System.Windows.Forms.Padding(2);
            this.lname_txt.Name = "lname_txt";
            this.lname_txt.Size = new System.Drawing.Size(162, 20);
            this.lname_txt.TabIndex = 2;
            // 
            // fname_txt
            // 
            this.fname_txt.Location = new System.Drawing.Point(102, 14);
            this.fname_txt.Margin = new System.Windows.Forms.Padding(2);
            this.fname_txt.Name = "fname_txt";
            this.fname_txt.Size = new System.Drawing.Size(162, 20);
            this.fname_txt.TabIndex = 1;
            // 
            // LastName
            // 
            this.LastName.AutoSize = true;
            this.LastName.Location = new System.Drawing.Point(15, 34);
            this.LastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(61, 13);
            this.LastName.TabIndex = 42;
            this.LastName.Text = "Last Name:";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Location = new System.Drawing.Point(15, 14);
            this.FirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(60, 13);
            this.FirstName.TabIndex = 43;
            this.FirstName.Text = "First Name:";
            // 
            // register_btn
            // 
            this.register_btn.Location = new System.Drawing.Point(457, 337);
            this.register_btn.Margin = new System.Windows.Forms.Padding(2);
            this.register_btn.Name = "register_btn";
            this.register_btn.Size = new System.Drawing.Size(83, 24);
            this.register_btn.TabIndex = 12;
            this.register_btn.Text = "Register";
            this.register_btn.UseVisualStyleBackColor = true;
            this.register_btn.Click += new System.EventHandler(this.register_btn_Click_1);
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(15, 140);
            this.Address.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(45, 13);
            this.Address.TabIndex = 38;
            this.Address.Text = "Address";
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(15, 161);
            this.State.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(35, 13);
            this.State.TabIndex = 37;
            this.State.Text = "State:";
            // 
            // address_txt
            // 
            this.address_txt.Location = new System.Drawing.Point(102, 140);
            this.address_txt.Margin = new System.Windows.Forms.Padding(2);
            this.address_txt.Name = "address_txt";
            this.address_txt.Size = new System.Drawing.Size(162, 20);
            this.address_txt.TabIndex = 7;
            // 
            // Statetxt
            // 
            this.Statetxt.Location = new System.Drawing.Point(102, 161);
            this.Statetxt.Margin = new System.Windows.Forms.Padding(2);
            this.Statetxt.Name = "Statetxt";
            this.Statetxt.Size = new System.Drawing.Size(162, 20);
            this.Statetxt.TabIndex = 8;
            // 
            // zip_txt
            // 
            this.zip_txt.Location = new System.Drawing.Point(102, 181);
            this.zip_txt.Margin = new System.Windows.Forms.Padding(2);
            this.zip_txt.Name = "zip_txt";
            this.zip_txt.Size = new System.Drawing.Size(162, 20);
            this.zip_txt.TabIndex = 9;
            // 
            // ZipCode
            // 
            this.ZipCode.AutoSize = true;
            this.ZipCode.Location = new System.Drawing.Point(15, 181);
            this.ZipCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ZipCode.Name = "ZipCode";
            this.ZipCode.Size = new System.Drawing.Size(50, 13);
            this.ZipCode.TabIndex = 36;
            this.ZipCode.Text = "ZipCode:";
            // 
            // Pregnanttxt
            // 
            this.Pregnanttxt.AutoSize = true;
            this.Pregnanttxt.Location = new System.Drawing.Point(15, 202);
            this.Pregnanttxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Pregnanttxt.Name = "Pregnanttxt";
            this.Pregnanttxt.Size = new System.Drawing.Size(59, 13);
            this.Pregnanttxt.TabIndex = 35;
            this.Pregnanttxt.Text = "Pregnant?:";
            // 
            // pregDrop
            // 
            this.pregDrop.FormattingEnabled = true;
            this.pregDrop.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.pregDrop.Location = new System.Drawing.Point(102, 202);
            this.pregDrop.Margin = new System.Windows.Forms.Padding(2);
            this.pregDrop.Name = "pregDrop";
            this.pregDrop.Size = new System.Drawing.Size(162, 21);
            this.pregDrop.TabIndex = 10;
            // 
            // Preexisting
            // 
            this.Preexisting.AutoSize = true;
            this.Preexisting.Location = new System.Drawing.Point(15, 323);
            this.Preexisting.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Preexisting.Name = "Preexisting";
            this.Preexisting.Size = new System.Drawing.Size(156, 13);
            this.Preexisting.TabIndex = 34;
            this.Preexisting.Text = "Pre-exisiting medical conditions:";
            // 
            // existing_txt
            // 
            this.existing_txt.Location = new System.Drawing.Point(194, 321);
            this.existing_txt.Margin = new System.Windows.Forms.Padding(2);
            this.existing_txt.Multiline = true;
            this.existing_txt.Name = "existing_txt";
            this.existing_txt.Size = new System.Drawing.Size(253, 63);
            this.existing_txt.TabIndex = 11;
            // 
            // date_birth
            // 
            this.date_birth.CustomFormat = "yyyy-MM-dd";
            this.date_birth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_birth.Location = new System.Drawing.Point(102, 55);
            this.date_birth.Margin = new System.Windows.Forms.Padding(2);
            this.date_birth.Name = "date_birth";
            this.date_birth.Size = new System.Drawing.Size(162, 20);
            this.date_birth.TabIndex = 3;
            // 
            // phone_lbl
            // 
            this.phone_lbl.AutoSize = true;
            this.phone_lbl.Location = new System.Drawing.Point(15, 97);
            this.phone_lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.phone_lbl.Name = "phone_lbl";
            this.phone_lbl.Size = new System.Drawing.Size(41, 13);
            this.phone_lbl.TabIndex = 0;
            this.phone_lbl.Text = "Phone:";
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(102, 97);
            this.phone_txt.Margin = new System.Windows.Forms.Padding(2);
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(162, 20);
            this.phone_txt.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = global::CovidVaccination.Properties.Resources.covid19;
            this.pictureBox2.Location = new System.Drawing.Point(372, 14);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(169, 293);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CovidVaccination.Properties.Resources.background;
            this.pictureBox1.Location = new System.Drawing.Point(5, -4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(659, 421);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // GetVaccine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 422);
            this.Controls.Add(this.phone_lbl);
            this.Controls.Add(this.phone_txt);
            this.Controls.Add(this.date_birth);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.existing_txt);
            this.Controls.Add(this.Preexisting);
            this.Controls.Add(this.pregDrop);
            this.Controls.Add(this.Pregnanttxt);
            this.Controls.Add(this.ZipCode);
            this.Controls.Add(this.zip_txt);
            this.Controls.Add(this.Statetxt);
            this.Controls.Add(this.address_txt);
            this.Controls.Add(this.State);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.register_btn);
            this.Controls.Add(this.genderDrop);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.email_txt);
            this.Controls.Add(this.lname_txt);
            this.Controls.Add(this.fname_txt);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.main_menu_btn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "GetVaccine";
            this.Text = "GetVaccine";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button main_menu_btn;
        private System.Windows.Forms.ComboBox genderDrop;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label DOB;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox lname_txt;
        private System.Windows.Forms.TextBox fname_txt;
        private System.Windows.Forms.Label LastName;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.Button register_btn;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.TextBox address_txt;
        private System.Windows.Forms.TextBox Statetxt;
        private System.Windows.Forms.TextBox zip_txt;
        private System.Windows.Forms.Label ZipCode;
        private System.Windows.Forms.Label Pregnanttxt;
        private System.Windows.Forms.ComboBox pregDrop;
        private System.Windows.Forms.Label Preexisting;
        private System.Windows.Forms.TextBox existing_txt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DateTimePicker date_birth;
        private System.Windows.Forms.Label phone_lbl;
        private System.Windows.Forms.TextBox phone_txt;
    }
}