﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using COVID_APP;

namespace CovidVaccination
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }
        //button 1 click event.
        private void button1_Click(object sender, EventArgs e)
        {
            //Create an mform and show the new form and hide the last form
            MainMenu mform = new MainMenu();
            mform.Show();
            this.Hide();
        }

        //Get help click event 
        private void GetHelp_Click(object sender, EventArgs e)
        {
            //Create an Hform and show the new form and hide the last form
            GetHelp Hform = new GetHelp();
            Hform.Show();
            this.Hide();
        }

        //Login2 Click 
        private void Login2_Click(object sender, EventArgs e)
        {
            //string cs = @"Data Source=.;Database=master;Integrated Security=True;";


            if (UsernametextBox.Text == "" || PasswordtextBox.Text == "")
            {
                MessageBox.Show("Please provide UserName and Password");
            
            }
            else if (PasswordtextBox.Text.Length <= 8)
            {
                MessageBox.Show("Password Must Contain at least 8 characters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!Regex.IsMatch(PasswordtextBox.Text, @"(!|@|#)") || !PasswordtextBox.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Password Must Contain at least a special character and digit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                PatientUpdate pform = new PatientUpdate();
                pform.Show();
                this.Hide();
            }
           
            /*else
            {
                PatientUpdate pform = new PatientUpdate();
                pform.Show();
                this.Hide();
            } */
        }
    }
}
