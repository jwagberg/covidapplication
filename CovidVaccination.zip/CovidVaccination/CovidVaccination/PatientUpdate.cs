﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CovidVaccination;

namespace COVID_APP
{
    public partial class PatientUpdate : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=agilewarriorscovidproject.database.windows.net;Initial Catalog=agile_warriors_covid_project;User ID=admin_1;Password=Password1");
        int Patient_ID = 0; 
        public PatientUpdate()
        {
            InitializeComponent();
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                if (save_btn.Text == "Save")
                {
                    SqlCommand sqlCmd = new SqlCommand("PatientAddOrEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Add");
                    sqlCmd.Parameters.AddWithValue("@Patient_ID", 0);
                    sqlCmd.Parameters.AddWithValue("@FirstName", fname_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@LastName", lname_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Phone", phone_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@VacAdmin", vac_admin_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@VacDate", vac_date.Text.Trim());
                    
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("New Patient Info Saved Successfully. Thank you.");
                }
                else
                {
                    SqlCommand sqlCmd = new SqlCommand("PatientAddOrEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                    sqlCmd.Parameters.AddWithValue("@Patient_ID", Patient_ID);
                    sqlCmd.Parameters.AddWithValue("@FirstName", fname_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@LastName", lname_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Phone", phone_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@VacAdmin", vac_admin_txt.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@VacDate", vac_date.Text.Trim());

                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("New Patient Info Updated Successfully. Thank you.");
                }
                Reset();
                FillPatientDataGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }
        void FillPatientDataGrid()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("PatientViewOrSearch", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@PatientName", search_txt.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            patientContacts.DataSource = dtbl;
            patientContacts.Columns[0].Visible = false;
            sqlCon.Close();
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            try
            {
                FillPatientDataGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void patientContacts_DoubleClick(object sender, EventArgs e)
        {
            if (patientContacts.CurrentRow.Index != -1)
            {
                Patient_ID = Convert.ToInt32(patientContacts.CurrentRow.Cells[0].Value.ToString());
                fname_txt.Text = patientContacts.CurrentRow.Cells[1].Value.ToString();
                lname_txt.Text = patientContacts.CurrentRow.Cells[2].Value.ToString();
                phone_txt.Text = patientContacts.CurrentRow.Cells[4].Value.ToString();
                vac_admin_txt.Text = patientContacts.CurrentRow.Cells[5].Value.ToString();
               
             
               
                save_btn.Text = "Update";
                delete_btn.Enabled = true;

            }
        }
        void Reset()
        {
            fname_txt.Text = lname_txt.Text = phone_txt.Text = vac_admin_txt.Text = " ";
            save_btn.Text = "Save";
            Patient_ID = 0;
            delete_btn.Enabled = false;
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Reset();
            FillPatientDataGrid();
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
       
                    SqlCommand sqlCmd = new SqlCommand("PatientDelete", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Patient_ID", Patient_ID);
                   
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Patient Info Deleted Successfully. Thank you.");
                Reset();
                FillPatientDataGrid();
                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

    }
}
