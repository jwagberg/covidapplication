﻿/*Team Agile Warriors COVID-19 Vaccination Project 
  Team Members: Andrew Hurlbut, Conor Kolmer, Jacob Wagberg
  Created: 03/2/21
  Last Updated: 03/09/21

  Patien Update Form

*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace CovidVaccination
{
    //Creates Form
    public partial class GetVaccine : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=agilewarriorscovidproject.database.windows.net;Initial Catalog=agile_warriors_covid_project;User ID=admin_1;Password=Password1");
        int Patient_ID = 0;
        public GetVaccine()
        {
            InitializeComponent();
        }

        //Register Button Click event to pull patient information.
        private void register_btn_Click_1(object sender, EventArgs e)
        {
            //variables and formating for phone number validation
            string phn = phone_txt.Text;
            Regex phoneRegex = new Regex(@"\(\d{3}\)\d{3}-\d{4}");
            Match phoneMatch = phoneRegex.Match(phn);

            //if phone numer is valid
            if (phoneMatch.Success)
            {

                try
                {
                    //check for sql connection and open if closed
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();
                    //if the text on the save button is 'Save' pull value from text boxes and upload into database
                    if (register_btn.Text == "Register")
                    {
                        SqlCommand sqlCmd = new SqlCommand("PatientAdd", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Patient_ID", 0);
                        sqlCmd.Parameters.AddWithValue("@FirstName", fname_txt.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@LastName", lname_txt.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DateBirth", date_birth.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Email", email_txt.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Phone", phone_txt.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Address", address_txt.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Zip", zip_txt.Text.Trim());



                        sqlCmd.ExecuteNonQuery();
                        MessageBox.Show("Thank you for registering, your information has been saved.");
                    }
                  

                    Reset();
             


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Message");
                }

                finally
                {
                    sqlCon.Close();
                }

                //Asks user to update because phone number format is incorrect
            }
            else
            {
                MessageBox.Show("Please enter phone number in (111)222-3333 format. Thank you. ");
                Reset();
            }
        }

        //Function to Reset the form
        void Reset()
        {
            fname_txt.Text = lname_txt.Text = email_txt.Text = phone_txt.Text = address_txt.Text = zip_txt.Text = " ";
            Patient_ID = 0;
           
        }
        private void main_menu_btn_Click(object sender, EventArgs e)
        {
            MainMenu mform = new MainMenu();
            mform.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
