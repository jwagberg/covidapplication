﻿
namespace CovidVaccination
{
    partial class CreateAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fname_txt = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.Label();
            this.DrFirstName_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DrLastName_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Pass_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PassConf_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.register_btn = new System.Windows.Forms.Button();
            this.main_menu_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fname_txt
            // 
            this.fname_txt.Location = new System.Drawing.Point(332, 53);
            this.fname_txt.Margin = new System.Windows.Forms.Padding(2);
            this.fname_txt.Name = "fname_txt";
            this.fname_txt.Size = new System.Drawing.Size(162, 20);
            this.fname_txt.TabIndex = 16;
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Location = new System.Drawing.Point(274, 53);
            this.FirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(60, 13);
            this.FirstName.TabIndex = 15;
            this.FirstName.Text = "First Name:";
            // 
            // DrFirstName_txt
            // 
            this.DrFirstName_txt.Location = new System.Drawing.Point(332, 53);
            this.DrFirstName_txt.Margin = new System.Windows.Forms.Padding(2);
            this.DrFirstName_txt.Name = "DrFirstName_txt";
            this.DrFirstName_txt.Size = new System.Drawing.Size(162, 20);
            this.DrFirstName_txt.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "First Name:";
            // 
            // DrLastName_txt
            // 
            this.DrLastName_txt.Location = new System.Drawing.Point(332, 93);
            this.DrLastName_txt.Margin = new System.Windows.Forms.Padding(2);
            this.DrLastName_txt.Name = "DrLastName_txt";
            this.DrLastName_txt.Size = new System.Drawing.Size(162, 20);
            this.DrLastName_txt.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(274, 93);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Last Name:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(332, 93);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(162, 20);
            this.textBox3.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(274, 93);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "First Name:";
            // 
            // Pass_txt
            // 
            this.Pass_txt.Location = new System.Drawing.Point(332, 134);
            this.Pass_txt.Margin = new System.Windows.Forms.Padding(2);
            this.Pass_txt.Name = "Pass_txt";
            this.Pass_txt.Size = new System.Drawing.Size(162, 20);
            this.Pass_txt.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(274, 134);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "Password:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(332, 134);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(162, 20);
            this.textBox5.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(274, 134);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "First Name:";
            // 
            // PassConf_txt
            // 
            this.PassConf_txt.Location = new System.Drawing.Point(332, 174);
            this.PassConf_txt.Margin = new System.Windows.Forms.Padding(2);
            this.PassConf_txt.Name = "PassConf_txt";
            this.PassConf_txt.Size = new System.Drawing.Size(162, 20);
            this.PassConf_txt.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(234, 174);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "Confirm Password:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(332, 174);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(162, 20);
            this.textBox7.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(274, 174);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "First Name:";
            // 
            // register_btn
            // 
            this.register_btn.Location = new System.Drawing.Point(359, 216);
            this.register_btn.Margin = new System.Windows.Forms.Padding(2);
            this.register_btn.Name = "register_btn";
            this.register_btn.Size = new System.Drawing.Size(83, 24);
            this.register_btn.TabIndex = 31;
            this.register_btn.Text = "Register";
            this.register_btn.UseVisualStyleBackColor = true;
            this.register_btn.Click += new System.EventHandler(this.register_btn_Click);
            // 
            // main_menu_btn
            // 
            this.main_menu_btn.Location = new System.Drawing.Point(359, 254);
            this.main_menu_btn.Margin = new System.Windows.Forms.Padding(2);
            this.main_menu_btn.Name = "main_menu_btn";
            this.main_menu_btn.Size = new System.Drawing.Size(83, 24);
            this.main_menu_btn.TabIndex = 32;
            this.main_menu_btn.Text = "Main Menu";
            this.main_menu_btn.UseVisualStyleBackColor = true;
            // 
            // CreateAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.main_menu_btn);
            this.Controls.Add(this.register_btn);
            this.Controls.Add(this.PassConf_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Pass_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DrLastName_txt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DrFirstName_txt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fname_txt);
            this.Controls.Add(this.FirstName);
            this.Name = "CreateAdmin";
            this.Text = "CreateAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox fname_txt;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.TextBox DrFirstName_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DrLastName_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Pass_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox PassConf_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button register_btn;
        private System.Windows.Forms.Button main_menu_btn;
    }
}