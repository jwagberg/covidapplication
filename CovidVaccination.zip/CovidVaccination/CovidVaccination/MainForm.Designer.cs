﻿
namespace CovidVaccination
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Admin = new System.Windows.Forms.Button();
            this.GetVaccine = new System.Windows.Forms.Button();
            this.GetHelp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.motto = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Admin
            // 
            this.Admin.Location = new System.Drawing.Point(267, 155);
            this.Admin.Margin = new System.Windows.Forms.Padding(2);
            this.Admin.Name = "Admin";
            this.Admin.Size = new System.Drawing.Size(97, 25);
            this.Admin.TabIndex = 2;
            this.Admin.Text = "Admin";
            this.Admin.UseVisualStyleBackColor = true;
            this.Admin.Click += new System.EventHandler(this.Login_Click);
            // 
            // GetVaccine
            // 
            this.GetVaccine.Location = new System.Drawing.Point(267, 193);
            this.GetVaccine.Margin = new System.Windows.Forms.Padding(2);
            this.GetVaccine.Name = "GetVaccine";
            this.GetVaccine.Size = new System.Drawing.Size(97, 25);
            this.GetVaccine.TabIndex = 3;
            this.GetVaccine.Text = "Get Vaccine";
            this.GetVaccine.UseVisualStyleBackColor = true;
            this.GetVaccine.Click += new System.EventHandler(this.GetVaccine_Click);
            // 
            // GetHelp
            // 
            this.GetHelp.Location = new System.Drawing.Point(267, 233);
            this.GetHelp.Margin = new System.Windows.Forms.Padding(2);
            this.GetHelp.Name = "GetHelp";
            this.GetHelp.Size = new System.Drawing.Size(97, 25);
            this.GetHelp.TabIndex = 4;
            this.GetHelp.Text = "Get Help";
            this.GetHelp.UseVisualStyleBackColor = true;
            this.GetHelp.Click += new System.EventHandler(this.GetHelp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 404);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Copyright © 2021 Created by the Agile Warriors";
            // 
            // motto
            // 
            this.motto.AutoSize = true;
            this.motto.Font = new System.Drawing.Font("Sitka Banner", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.motto.Image = global::CovidVaccination.Properties.Resources.background;
            this.motto.Location = new System.Drawing.Point(121, 89);
            this.motto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.motto.Name = "motto";
            this.motto.Size = new System.Drawing.Size(399, 33);
            this.motto.TabIndex = 6;
            this.motto.Text = "Working together to heal our community.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CovidVaccination.Properties.Resources.background;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(673, 451);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
          
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 422);
            this.Controls.Add(this.motto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GetHelp);
            this.Controls.Add(this.GetVaccine);
            this.Controls.Add(this.Admin);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainMenu";
            this.Text = "Main Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Admin;
        private System.Windows.Forms.Button GetVaccine;
        private System.Windows.Forms.Button GetHelp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label motto;
    }
}