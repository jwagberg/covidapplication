﻿//Andrew Hurlbut Conor Kolmer Jacob Wagberg 
namespace COVID_APP
{
    partial class PatientUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.save_btn = new System.Windows.Forms.Button();
            this.fname_txt = new System.Windows.Forms.TextBox();
            this.patientContacts = new System.Windows.Forms.DataGridView();
            this.delete_btn = new System.Windows.Forms.Button();
            this.reset_btn = new System.Windows.Forms.Button();
            this.lname_txt = new System.Windows.Forms.TextBox();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.fname_lbl = new System.Windows.Forms.Label();
            this.phone_lbl = new System.Windows.Forms.Label();
            this.lname_lbl = new System.Windows.Forms.Label();
            this.search_btn = new System.Windows.Forms.Button();
            this.search_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.type_lbl = new System.Windows.Forms.Label();
            this.dr_lbl = new System.Windows.Forms.Label();
            this.vac_admin_txt = new System.Windows.Forms.TextBox();
            this.pfz_chckbx = new System.Windows.Forms.CheckBox();
            this.mod_chckbx = new System.Windows.Forms.CheckBox();
            this.jj_chckbx = new System.Windows.Forms.CheckBox();
            this.vac_date = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.patientContacts)).BeginInit();
            this.SuspendLayout();
            // 
            // save_btn
            // 
            this.save_btn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.save_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.save_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.save_btn.FlatAppearance.BorderSize = 3;
            this.save_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.save_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.save_btn.Location = new System.Drawing.Point(176, 400);
            this.save_btn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(334, 68);
            this.save_btn.TabIndex = 0;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // fname_txt
            // 
            this.fname_txt.Location = new System.Drawing.Point(176, 18);
            this.fname_txt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.fname_txt.Name = "fname_txt";
            this.fname_txt.Size = new System.Drawing.Size(278, 26);
            this.fname_txt.TabIndex = 1;
            // 
            // patientContacts
            // 
            this.patientContacts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.patientContacts.Location = new System.Drawing.Point(526, 149);
            this.patientContacts.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.patientContacts.Name = "patientContacts";
            this.patientContacts.RowHeadersWidth = 62;
            this.patientContacts.Size = new System.Drawing.Size(656, 525);
            this.patientContacts.TabIndex = 2;
            this.patientContacts.DoubleClick += new System.EventHandler(this.patientContacts_DoubleClick);
            // 
            // delete_btn
            // 
            this.delete_btn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.delete_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.delete_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.delete_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.delete_btn.FlatAppearance.BorderSize = 3;
            this.delete_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.delete_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.delete_btn.Location = new System.Drawing.Point(174, 477);
            this.delete_btn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(336, 68);
            this.delete_btn.TabIndex = 3;
            this.delete_btn.Text = "Delete";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // reset_btn
            // 
            this.reset_btn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.reset_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.reset_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reset_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.reset_btn.FlatAppearance.BorderSize = 3;
            this.reset_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.reset_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.reset_btn.Location = new System.Drawing.Point(174, 554);
            this.reset_btn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(336, 68);
            this.reset_btn.TabIndex = 4;
            this.reset_btn.Text = "Reset";
            this.reset_btn.UseVisualStyleBackColor = false;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // lname_txt
            // 
            this.lname_txt.Location = new System.Drawing.Point(176, 60);
            this.lname_txt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lname_txt.Name = "lname_txt";
            this.lname_txt.Size = new System.Drawing.Size(278, 26);
            this.lname_txt.TabIndex = 5;
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(176, 102);
            this.phone_txt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(278, 26);
            this.phone_txt.TabIndex = 6;
            // 
            // fname_lbl
            // 
            this.fname_lbl.AutoSize = true;
            this.fname_lbl.Location = new System.Drawing.Point(80, 18);
            this.fname_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fname_lbl.Name = "fname_lbl";
            this.fname_lbl.Size = new System.Drawing.Size(86, 20);
            this.fname_lbl.TabIndex = 8;
            this.fname_lbl.Text = "First Name";
            // 
            // phone_lbl
            // 
            this.phone_lbl.AutoSize = true;
            this.phone_lbl.Location = new System.Drawing.Point(104, 105);
            this.phone_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.phone_lbl.Name = "phone_lbl";
            this.phone_lbl.Size = new System.Drawing.Size(59, 20);
            this.phone_lbl.TabIndex = 9;
            this.phone_lbl.Text = "Phone ";
            // 
            // lname_lbl
            // 
            this.lname_lbl.AutoSize = true;
            this.lname_lbl.Location = new System.Drawing.Point(80, 63);
            this.lname_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lname_lbl.Name = "lname_lbl";
            this.lname_lbl.Size = new System.Drawing.Size(86, 20);
            this.lname_lbl.TabIndex = 11;
            this.lname_lbl.Text = "Last Name";
            // 
            // search_btn
            // 
            this.search_btn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.search_btn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.search_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.search_btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.search_btn.FlatAppearance.BorderSize = 3;
            this.search_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.search_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.search_btn.Location = new System.Drawing.Point(969, 57);
            this.search_btn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(194, 68);
            this.search_btn.TabIndex = 12;
            this.search_btn.Text = "Search";
            this.search_btn.UseVisualStyleBackColor = false;
            this.search_btn.Click += new System.EventHandler(this.search_btn_Click);
            // 
            // search_txt
            // 
            this.search_txt.Location = new System.Drawing.Point(651, 57);
            this.search_txt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.search_txt.Name = "search_txt";
            this.search_txt.Size = new System.Drawing.Size(278, 26);
            this.search_txt.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 168);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Date of Vaccination";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 314);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 20;
            // 
            // type_lbl
            // 
            this.type_lbl.AutoSize = true;
            this.type_lbl.Location = new System.Drawing.Point(41, 239);
            this.type_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.type_lbl.Name = "type_lbl";
            this.type_lbl.Size = new System.Drawing.Size(122, 20);
            this.type_lbl.TabIndex = 19;
            this.type_lbl.Text = "Type of Vaccine";
            // 
            // dr_lbl
            // 
            this.dr_lbl.AutoSize = true;
            this.dr_lbl.Location = new System.Drawing.Point(21, 137);
            this.dr_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dr_lbl.Name = "dr_lbl";
            this.dr_lbl.Size = new System.Drawing.Size(145, 20);
            this.dr_lbl.TabIndex = 18;
            this.dr_lbl.Text = "Vaccine Administer";
            // 
            // vac_admin_txt
            // 
            this.vac_admin_txt.Location = new System.Drawing.Point(176, 134);
            this.vac_admin_txt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.vac_admin_txt.Name = "vac_admin_txt";
            this.vac_admin_txt.Size = new System.Drawing.Size(278, 26);
            this.vac_admin_txt.TabIndex = 14;
            // 
            // pfz_chckbx
            // 
            this.pfz_chckbx.AutoSize = true;
            this.pfz_chckbx.Location = new System.Drawing.Point(174, 214);
            this.pfz_chckbx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pfz_chckbx.Name = "pfz_chckbx";
            this.pfz_chckbx.Size = new System.Drawing.Size(68, 24);
            this.pfz_chckbx.TabIndex = 22;
            this.pfz_chckbx.Text = "Pfizer";
            this.pfz_chckbx.UseVisualStyleBackColor = true;
            // 
            // mod_chckbx
            // 
            this.mod_chckbx.AutoSize = true;
            this.mod_chckbx.ForeColor = System.Drawing.SystemColors.ControlText;
            this.mod_chckbx.Location = new System.Drawing.Point(174, 248);
            this.mod_chckbx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mod_chckbx.Name = "mod_chckbx";
            this.mod_chckbx.Size = new System.Drawing.Size(91, 24);
            this.mod_chckbx.TabIndex = 23;
            this.mod_chckbx.Text = "Moderna";
            this.mod_chckbx.UseVisualStyleBackColor = true;
            // 
            // jj_chckbx
            // 
            this.jj_chckbx.AutoSize = true;
            this.jj_chckbx.Location = new System.Drawing.Point(174, 282);
            this.jj_chckbx.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jj_chckbx.Name = "jj_chckbx";
            this.jj_chckbx.Size = new System.Drawing.Size(167, 24);
            this.jj_chckbx.TabIndex = 24;
            this.jj_chckbx.Text = "Johnnson & Johnson";
            this.jj_chckbx.UseVisualStyleBackColor = true;
            // 
            // vac_date
            // 
            this.vac_date.AllowDrop = true;
            this.vac_date.CustomFormat = "yyyy-MM-dd";
            this.vac_date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.vac_date.Location = new System.Drawing.Point(176, 168);
            this.vac_date.Name = "vac_date";
            this.vac_date.Size = new System.Drawing.Size(124, 26);
            this.vac_date.TabIndex = 25;
            // 
            // PatientUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::CovidVaccination.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.vac_date);
            this.Controls.Add(this.jj_chckbx);
            this.Controls.Add(this.mod_chckbx);
            this.Controls.Add(this.pfz_chckbx);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.type_lbl);
            this.Controls.Add(this.dr_lbl);
            this.Controls.Add(this.vac_admin_txt);
            this.Controls.Add(this.search_txt);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.lname_lbl);
            this.Controls.Add(this.phone_lbl);
            this.Controls.Add(this.fname_lbl);
            this.Controls.Add(this.phone_txt);
            this.Controls.Add(this.lname_txt);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.delete_btn);
            this.Controls.Add(this.patientContacts);
            this.Controls.Add(this.fname_txt);
            this.Controls.Add(this.save_btn);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "PatientUpdate";
            this.Text = "Patient Update Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.patientContacts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.TextBox fname_txt;
        private System.Windows.Forms.DataGridView patientContacts;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.TextBox lname_txt;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.Label fname_lbl;
        private System.Windows.Forms.Label phone_lbl;
        private System.Windows.Forms.Label lname_lbl;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.TextBox search_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label type_lbl;
        private System.Windows.Forms.Label dr_lbl;
        private System.Windows.Forms.TextBox vac_admin_txt;
        private System.Windows.Forms.CheckBox pfz_chckbx;
        private System.Windows.Forms.CheckBox mod_chckbx;
        private System.Windows.Forms.CheckBox jj_chckbx;
        private System.Windows.Forms.DateTimePicker vac_date;
    }
}

